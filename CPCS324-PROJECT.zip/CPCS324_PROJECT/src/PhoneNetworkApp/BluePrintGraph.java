/*
 * 
 */
package PhoneNetworkApp;

import GraphFramework.Edge;
import GraphFramework.Graph;
import GraphFramework.Vertex;

/**
 *
 *
 */
public class BluePrintGraph extends Graph{
    public BluePrintGraph(int v, int e, boolean digraph){
        super(v, e, digraph);
    }
    public BluePrintGraph(){
        
    }
    @Override
    public Vertex createVertex(String label){
        return new Office(label);
    }
    @Override
    public Edge createEdge(Vertex s, Vertex t, int weight){
        return new Line(s, t, weight);
    }
}
