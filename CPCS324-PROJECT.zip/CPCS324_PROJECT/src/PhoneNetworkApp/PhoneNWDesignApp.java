/*
 * 
 */
package PhoneNetworkApp;
import GraphFramework.*;
import java.io.File;
import java.io.IOException;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * 
 */
public class PhoneNWDesignApp {
    public static void main(String[] args) throws IOException {
        Graph PhLNetwork;
        Scanner input = new Scanner(System.in);
        System.out.print("(1) For requirement 1 (readGraphFromFile) method.\n(2) For requirement 2 (make_graph) method.\n");
        System.out.print("Please select an option : ");
        int intOption = input.nextInt();
        while(intOption != 1 && intOption != 2){
            System.out.println("Incorrect option, there are only 2 options available (1 and 2)..");
            System.out.println("Please select an option : ");
            intOption = input.nextInt();
        }
        MSTAlgorithm.requirementNumber = intOption;
        if (intOption == 1){
            System.out.println("You've selected the requirement 1 (readGraphFromFile), you'll find the result below ->>>> ");
            PhLNetwork = new BluePrintGraph();
            PhLNetwork.readGraphFromFile(new File("src/graph_file.txt"));

            System.out.println("================== Kruskal's algorithm ===================");
            double ms = System.currentTimeMillis();
            KruskalAlg2 kruskalAlg = new KruskalAlg2(PhLNetwork);
            ms = System.currentTimeMillis() - ms;
            kruskalAlg.displayResultingMST();
            System.out.println("Running time : "+ms);

            System.out.println("================== Min Heap Prim's algorithm ===================");
            ms = System.currentTimeMillis();
            MHPrimAlg mhPrimAlg = new MHPrimAlg(PhLNetwork);
            ms = System.currentTimeMillis() - ms;
            mhPrimAlg.displayResultingMST();
            System.out.println("Running time : "+ms);
        }else{
            int v = 0;
            int e = 0;
            System.out.println("You've selected the requirement 2 (make_graph)\nPlease select the case number : ");
            System.out.println("1- n=1000 m=10000");
            System.out.println("2- n=1000 m=15000");
            System.out.println("3- n=1000 m=25000");
            System.out.println("4- n=5000 m=15000");
            System.out.println("5- n=5000 m=25000");
            System.out.println("6- n=10000 m=15000");
            System.out.println("7- n=10000 m=25000");
            System.out.println("Please select an option : ");
            intOption = input.nextInt();
            while(intOption > 7 || intOption < 1){
                System.out.println("Incorrect case, there are only 7 cases available to choose...");
                System.out.println("Please select an option : ");
                intOption = input.nextInt();
            }
            switch(intOption){
                case 1:
                    v=1000;e=10000;
                    break;
                case 2:
                    v=1000;e=15000;
                    break;
                case 3:
                    v=1000;e=25000;
                    break;
                case 4:
                    v=5000;e=15000;
                    break;
                case 5:
                    v=5000;e=25000;
                    break;
                case 6:
                    v=10000;e=15000;
                    break;
                case 7:
                    v=10000;e=25000;
            }
            System.out.println("We're almost done, Is the graph planned to be a directed graph? (y/n) ");
            String option = input.next();
            while(!option.equalsIgnoreCase("y")&&!option.equalsIgnoreCase("n")){
                System.out.println("Is the graph planned to be a directed graph? (y/n) ");
                option = input.next();
            }
            boolean isDigraph = option.equals('y');
            PhLNetwork = new BluePrintGraph(6, 8, isDigraph);
            PhLNetwork.make_graph(6, 8);

            System.out.println("================== Kruskal's algorithm ===================");
            double ms = System.currentTimeMillis();
            KruskalAlg2 kruskalAlg = new KruskalAlg2(PhLNetwork);
            ms = System.currentTimeMillis() - ms;
            kruskalAlg.displayResultingMST();
            System.out.println("Running time : "+ms);

            System.out.println("================== Min Heap Prim's algorithm ===================");
            ms = System.currentTimeMillis();
            MHPrimAlg mhPrimAlg = new MHPrimAlg(PhLNetwork);
            ms = System.currentTimeMillis() - ms;
            mhPrimAlg.displayResultingMST();
            System.out.println("Running time : "+ms);
        }
    }
}
