/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PhoneNetworkApp;
import GraphFramework.*;

/**
 *
 * 
 */
public class Line extends Edge{
    private int lLength;
    public Line(Vertex source, Vertex target, int weight){
        super(source,target,weight);
        this.lLength = weight * 5;
    }
    
    @Override
    public String displayInfo(){
        return "Line length : "+lLength;
    }
}
