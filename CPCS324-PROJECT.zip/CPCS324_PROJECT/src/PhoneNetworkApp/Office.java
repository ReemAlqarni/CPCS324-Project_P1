/*
 * 
 */
package PhoneNetworkApp;
import GraphFramework.*;
import java.util.LinkedList;
/**
 *
 * 
 */
public class Office extends Vertex {
    public Office(String label){
        super(label);
        this.adjList = new LinkedList<>();
    }
    @Override
    public String displayInfo(){
        return "Office name : "+(char)65+Integer.valueOf(label);
    }
}
