/*
 * 
 */
package GraphFramework;

import PhoneNetworkApp.Line;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * 
 */
public class KruskalAlg extends MSTAlgorithm {
    public class DisjointSet{
        private final LinkedList<LinkedList<Vertex>> Sets = new LinkedList<>();
        public DisjointSet(Graph graph){
            int vNumber = graph.verticesNo;
            // Add each vertex to a single set
            // Example, If we have A,B,C,D,E as vertices
            // That means Sets going to be like { {A},{B},{C},{D},{E} }
            for(int i=0;i<vNumber;i++){
                LinkedList<Vertex> newSet;
                newSet = new LinkedList<>();
                newSet.add(graph.vertices[ i ]);
                this.Sets.add(newSet);
            }
        }
        // Get Sets LinkedList of this object.
        public LinkedList<LinkedList<Vertex>> GetSets(){return this.Sets;}
        // Below LinkSets method inserts the set2 vertices to set1 and remove set2 from the Sets list..
        // That means we merge them.
        public boolean LinkSets(int set1, int set2){
            LinkedList<Vertex> set2Set = this.GetSets().get(set2);
            LinkedList<Vertex> set1Set = this.GetSets().get(set1);
            for (Vertex vertex : set2Set){
                set1Set.add(vertex);
            }
            this.GetSets().remove(set2Set);
            return true;
        }
        // Get the Set index of a vertex.
        public int GetSetIndex(Vertex vertex){
            for (int index = 0; index < this.GetSets().size(); index++){
                LinkedList<Vertex> iterSet = this.GetSets().get(index);
                if(iterSet.contains(vertex)){
                    return index;
                }
            }
            return -1;
        }
        // inSameSet method returns a boolean value, true if both given vertices are in the same set.
        public boolean inSameSet(Vertex v1, Vertex v2){
            return GetSetIndex(v1) == GetSetIndex(v2);
        }
    }
    public KruskalAlg(Graph graph){
        super(graph);
        // Get all graph's edges
        List<Edge> graphEdges = new LinkedList<>();
        for(Vertex v : graph.vertices){
            for(Edge edge : v.adjList){
                graphEdges.add(edge);
            }
        }
        // Sort the edges by weight
        // Example :
        // Edge1 : source: 0 target: 1 weight 8
        // Edge2 : source: 1 target: 2 weight 2
        // Edge3 : source: 2 target: 3 weight 4
        // Edge4 : source: 3 target: 4 weight 7
        // after sorting, the graphEdges has to be :
        // { Edge2, Edge3, Edge4, Edge1 }
        graphEdges.sort(new Comparator<Edge>() {
            @Override public int compare(Edge o1, Edge o2)
            {
                return o1.weight - o2.weight;
            }
        });
        // Create a disjoint set.
        DisjointSet disjointSet = new DisjointSet(this.graph);
        
        // Loop through all edges
        for (Edge edge: graphEdges){
            Vertex source = edge.source;
            Vertex target = edge.target;
            
            // If source and target of the current edge are in the same set, then we have to skip this iteration.
            if (disjointSet.inSameSet(source, target)){
                continue;
            }
            // If above condition is false ..
            // We link the two sets of source and target by their indices.
            disjointSet.LinkSets(disjointSet.GetSetIndex(source), disjointSet.GetSetIndex(target));
            // Add this edge to the MSTResultSet list.
            this.MSTResultSet.add(edge);
            // If MSTResultSet's size is equals to (Vertices Number - 1), then break the loop.
            if(this.MSTResultSet.size() == this.graph.verticesNo - 1){break;}
        }
    }
    
    @Override
    public void displayResultingMST(){
        int MSTCost = 0;
        this.MSTResultSet.sort(new Comparator<Edge>(){
            @Override
            public int compare(Edge o1, Edge o2) {
                return (int)o1.source.label.charAt(0)-(int)o2.source.label.charAt(0);
            }
            
        });
        //this.MSTResultSet.sort((Edge o1, Edge o2) -> Integer.valueOf(o1.source.label)-Integer.valueOf(o2.source.label));
        for (Edge edge : this.MSTResultSet){
            MSTCost += edge.weight;
            if(MSTAlgorithm.requirementNumber == 1){
                int sourceIndex = graph.GetVertexIndex(edge.source);
                int targetIndex = graph.GetVertexIndex(edge.target);
                char sourceLabel = graph.labels[sourceIndex];
                char targetLabel = graph.labels[targetIndex];
                Line line = (Line)edge;
                System.out.println("Office No. "+sourceLabel+" - Office No. "+targetLabel+" : "+line.displayInfo()+" : Weight : "+edge.weight);
            }
        }
        System.out.println("MST Cost : "+MSTCost);
    }
    public final LinkedList<Edge> GetAllGraphEdges(){
        LinkedList<Edge> allEdges;
        allEdges = new LinkedList<>();
        for (int v = 0; v < this.graph.verticesNo; v++){
            for (int e = 0; e < this.graph.vertices[ v ].adjList.size(); e++){
                allEdges.add(this.graph.vertices[ v ].adjList.get(e));
            }
        }
        return allEdges;
    }
}
