/*
 *
 */
package GraphFramework;
import PhoneNetworkApp.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.Stream;

/**
 *
 * 
 */
public class Graph {
    public int verticesNo;
    public int edgesNo;
    public boolean isDigraph = false;
    public Vertex[] vertices;
    public List<Edge> edges;
    public char[] labels;
    public Graph blueprint;
    
    public Graph(int vNum, int eNum, boolean digraph){
        this.verticesNo = vNum;
        this.edgesNo = eNum;
        this.vertices = new Vertex[ vNum ];
        this.edges = new ArrayList<>();
        this.isDigraph = digraph;
        this.labels = new char[vNum];
    }
    
    public Graph(){
        
    }
    
    public Vertex createVertex(String label){
        return new Vertex(label);
    }
    
    public Edge createEdge(Vertex s, Vertex t, int weight){
        return new Edge(s, t, weight);
    }
    
    public Edge addEdge(int v, int u, int weight){
        blueprint = new BluePrintGraph();
        if(vertices[ v ] == null){
            verticesNo++;
            vertices[ v ] = blueprint.createVertex(Integer.toString(v));
            labels[ v ] = vertices[ v ].label.charAt(0);
        }
        if(vertices[ u ] == null){
            verticesNo++;
            vertices[ u ] = blueprint.createVertex(Integer.toString(u));
            labels[ u ] = vertices[ u ].label.charAt(0);
        }
        Edge new_edge = blueprint.createEdge(vertices[ v ], vertices[ u ], weight);
        edgesNo++;
        vertices[ v ].adjList.add(new_edge);
        edges.add(new_edge);
        if(!isDigraph){
            new_edge = blueprint.createEdge(vertices[ u ], vertices[ v ], weight);
            edgesNo++;
            vertices[ u ].adjList.add(new_edge);
        }
        return new_edge;
    }
    
    public void readGraphFromFile(File fileName) throws FileNotFoundException{
        Scanner input = new Scanner(fileName);
        String graph_type = input.nextLine();
        
        if(graph_type.equalsIgnoreCase("digraph 0")){
            isDigraph = false;
        }
        
        if(graph_type.equalsIgnoreCase("digraph 1")){
            isDigraph = true;
        }
        
        int V = input.nextInt();
        int E = input.nextInt();
        System.out.println(E);
        if(!isDigraph){
            E *= 2;
        }
        
        vertices = new Vertex[ V ];
        this.labels = new char[ V ];
        this.edges = new ArrayList<>();
        while(edgesNo < E){
            char src = input.next().charAt(0);
            char dest = input.next().charAt(0);
            labels[src-65] = src;
            labels[dest-65] = dest;
            int weight = input.nextInt();
            addEdge(src-65, dest-65, weight);
        }
        input.close();
    }
    
    public void make_graph(int V, int E){
        if(!this.isDigraph){
            E*=2;
            edgesNo*=2;
        }
        Random random = new Random();
        for(int i = 0; i < V; i++){
            vertices[ i ] = new Vertex(Integer.toString(i));
        }
        for(int i = 0; i < V - 1; i++){
            addEdge(Integer.parseInt(vertices[ i ].label), Integer.parseInt(vertices[ i+1 ].label), (int) (1 + Math.random() * 10));
        }
        int i = 0;
        while(i < (E-(V - 1))){
            int VertexU = random.nextInt(V);
            int VertexV = random.nextInt(V);
            if(VertexU==VertexV) continue;
            for(int j = 0; j < vertices[ VertexU ].adjList.size(); j++){
                if(Integer.parseInt(vertices[ VertexU ].adjList.get(j).target.label) != VertexV){
                    break;
                }
            }
            addEdge(Integer.parseInt(vertices[ VertexU ].label), Integer.parseInt(vertices[ VertexV ].label), (int) (1 + Math.random() * 10));
            i++;
        }
    }
    
    public Vertex GetVertexByIndex(int index){
        return this.vertices[ index ];
    }
    
    public int GetVertexIndex(Vertex vertex){
        int i = 0;
        for(Vertex v : vertices){
            if(v==vertex) return i;
            i++;
        }
        return -1;
    }
    
    public List<List<Edge>> GetEdges(){
        List<List<Edge>> result = new ArrayList<>();
        for(Vertex vertex : vertices){
            List<Edge> vEdges = vertex.adjList;
            result.add(vEdges);
        }
        return result;
    }
}
