/*
 * 
 */
package GraphFramework;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * 
 */
public class MHPrimAlg extends MSTAlgorithm{
    class Set{
        int source;
        int key;
    }
    List<Set> MSTResultSet;
    public MHPrimAlg(Graph graph){
        super(graph);
        int V = graph.verticesNo;
        int MAX = Integer.MAX_VALUE;
        MSTResultSet = new ArrayList<>(V);
        boolean[] in_heap = new boolean[V];
        Node[] heapNodes = new Node[V];
        int[] key = new int[V];
        for(int i = 0; i < V; i++){
            heapNodes[ i ] = new Node(i, MAX);
            in_heap[ i ] = true;
            key[ i ] = MAX;
            MSTResultSet.add(new Set());
            MSTResultSet.get(i).source = -1;
        }
        heapNodes[ 0 ].key = 0;
        MinHeap MH = new MinHeap(V);
        for(Node heapNode : heapNodes){
            MH.insert(heapNode);
        }
        while(!MH.IsEmpty()){
            Node min_node = MH.extract_min();
            int v = min_node.vertex;
            
            in_heap[ v ] = false;
            Vertex v_Vertex = graph.GetVertexByIndex(v);
            List<Edge> adjList = v_Vertex.adjList;
            for(Edge edge : adjList){
                int target_index = graph.GetVertexIndex(edge.target);
                if(in_heap[target_index]){
                    int new_key = edge.weight;
                    if(key[target_index] > new_key){
                        MH.decreaseKey(target_index, new_key);
                        MSTResultSet.get(target_index).source = v;
                        MSTResultSet.get(target_index).key = new_key;
                        key[target_index] = new_key;
                    }
                    
                }
            }
        }
    }
    
    @Override
    public void displayResultingMST(){
        int mst_cost = 0;
        for(int i = 0; i < MSTResultSet.size(); ++i){
            Set set = MSTResultSet.get(i);
            if (set.source == -1){
                if (i+1 == MSTResultSet.size()) break;
                continue;
            }
            //if(MSTAlgorithm.requirementNumber == 1){
                Vertex sourceVertex = graph.GetVertexByIndex(set.source);
                Vertex targetVertex = graph.GetVertexByIndex(i);
                char sourceLabel = sourceVertex.label.charAt(0);
                char targetLabel = targetVertex.label.charAt(0);
                if(graph.labels != null){
                    // This condition should be true only if the selected requirement is 1 (readGraphFromFile)
                    // We'll bring the labels from labels list in graph using index of vertex;
                    sourceLabel = graph.labels[set.source];
                    targetLabel = graph.labels[i];
                    System.out.println("Office No. "+sourceLabel+" - Office No. "+targetLabel+" : Line Length "+set.key*5+" : Weight : "+set.key);
                }
                else{
                    // If the selected requirement is NOT 1 (readGraphFromFile)
                    // Then, we only need to print the index of vertex not the character, because it's generated graph.
                    System.out.println("Office No. "+sourceLabel+" - Office No. "+targetLabel+" : Line Length "+set.key*5+" : Weight : "+set.key);
                }
            //}
            mst_cost += set.key;
        }
        System.out.println("MST Cost : "+mst_cost);
    }
}
