/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GraphFramework;

/**
 *
 */
public class MinHeap {
    int N;
    Node[] heap;
    int[] index; // Index list will be used in decreasing keys
    
    public MinHeap(int vnum){
        heap = new Node[vnum + 1];
        index = new int[vnum];
        heap[ 0 ] = new Node(-1, Integer.MIN_VALUE);
        N=0;
    }
    
    public void insert(Node node){
        N++;
        heap[ N ] = node;
        upHeap(N);
    }
    
    public void upHeap(int k){
        Node node = heap[ k ];
        while(k > 0 && heap[k / 2].key() >= node.key()){
            heap[ k ] = heap[k / 2];
            k = k / 2;
        }
        heap[ k ] = node;
    }
    
    public Node extract_min() {
        Node min = heap[1];
        Node lastNode = heap[N];
        
        heap[1] = lastNode;
        heap[N] = null;
        downHeap(1);
        N--;
        return min;
    }
    
    public void downHeap(int key) {
        int smallest = key;
        int leftChildIdx = 2 * key;
        int rightChildIdx = 2 * key + 1;
        if (leftChildIdx < N && heap[smallest].key > heap[leftChildIdx].key) {
            smallest = leftChildIdx;
        }
        if (rightChildIdx < N && heap[smallest].key > heap[rightChildIdx].key) {
            smallest = rightChildIdx;
        }
        if (smallest != key) {
            // Swap positions
            swap(key, smallest);
            downHeap(smallest);
        }
    }
    
    public void decreaseKey(int v, int new_key) {
        int i = index[v];
        Node node = heap[i];
        node.key = new_key;
        upHeap(i);
    }
    
    public void swap(int a, int b) {
        Node temp = heap[a];
        heap[a] = heap[b];
        heap[b] = temp;
    }
    public boolean IsEmpty(){
        return N == 0;
    }
}
