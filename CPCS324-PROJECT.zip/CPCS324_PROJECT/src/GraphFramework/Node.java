/*
 * 
 */
package GraphFramework;

/**
 *
 * 
 */
public class Node {
    public int vertex;
    public int key;
    public Node(int v, int k){
        vertex=v;
        key=k;
    }
    public int key(){
        return key;
    }
}
