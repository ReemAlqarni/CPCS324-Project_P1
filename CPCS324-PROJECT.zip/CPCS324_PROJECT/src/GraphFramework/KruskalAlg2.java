/*
 * 
 */
package GraphFramework;

import PhoneNetworkApp.Line;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author Mohammed
 */
public class KruskalAlg2 extends MSTAlgorithm{
    class Set{
        int parent;
        int key;
        public Set(int parent, int key){
            this.parent=parent;
            this.key=key;
        }
    }
    Edge[] MSTResultSet;
    public KruskalAlg2(Graph graph){
        super(graph);
        List<Edge> edges = graph.edges;
        edges.sort(new Comparator<Edge>() {
            @Override public int compare(Edge o1, Edge o2)
            {
                return o1.weight - o2.weight;
            }
        });
        
        int V = graph.verticesNo;
        //int E = graph.edgesNo;
        
        int j = 0;
        int e_count = 0;// Number of edges added to MSTResultSet
        Set[] sets = new Set[ V ];
        MSTResultSet = new Edge[ V ];
        
        for (int i = 0; i < V; i++) {
            sets[ i ] = new Set(i, 0);
        }
        
        // Number of edges to be taken is equal to V-1
        while (e_count < V - 1) {
 
            // Pick the smallest edge. And increment
            // the index for next iteration
            Edge nextEdge = edges.get(j);
            int x = findRoot(sets, graph.GetVertexIndex(nextEdge.source));
            int y = findRoot(sets, graph.GetVertexIndex(nextEdge.target));
 
            // If including this edge doesn't cause cycle,
            // include it in result and increment the index
            // of result for next edge
            if (x != y) {
                MSTResultSet[e_count] = nextEdge;
                union(sets, x, y);
                e_count++;
            }
 
            j++;
        }
        displayResultingMST(e_count);
    }
    
    public void displayResultingMST(int e_count){
        // Print the contents of result[] to display the
        // built MST
        int MSTCost = 0;
        for (int i = 0; i < e_count; i++) {
            Edge edge = MSTResultSet[ i ];
            MSTCost += edge.weight;
            //if(MSTAlgorithm.requirementNumber == 1){
                Line line = (Line)edge;
                int sourceIndex = graph.GetVertexIndex(edge.source);
                int targetIndex = graph.GetVertexIndex(edge.target);
                char sourceLabel = graph.labels[sourceIndex];
                char targetLabel = graph.labels[targetIndex];
                System.out.println("Office No. "+sourceLabel+" - Office No. "+targetLabel+" : "+line.displayInfo()+" : Weight : "+edge.weight);
            //}
        }
        System.out.println("MST Cost : " + MSTCost);
    }
    // Function to find parent of a set
    private static int findRoot(Set[] sets, int i)
    {
        if (sets[i].parent == i)
            return sets[i].parent;
 
        sets[i].parent
            = findRoot(sets, sets[i].parent);
        return sets[i].parent;
    }
    
    // Function to unite two disjoint sets
    private static void union(Set[] sets, int x,
                              int y)
    {
        int rootX = findRoot(sets, x);
        int rootY = findRoot(sets, y);
 
        if (sets[rootY].key < sets[rootX].key) {
            sets[rootY].parent = rootX;
        }
        else if (sets[rootX].key
                 < sets[rootY].key) {
            sets[rootX].parent = rootY;
        }
        else {
            sets[rootY].parent = rootX;
            sets[rootX].key++;
        }
    }
}
