/*
 * 
 */
package GraphFramework;
import PhoneNetworkApp.*;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * 
 */
public class MSTAlgorithm {
    public Graph graph;
    public List<Edge> MSTResultSet;
    public static int requirementNumber = 1;
    public MSTAlgorithm(Graph graph){
        this.graph = graph;
        this.MSTResultSet = new LinkedList<>();
    }
    public void displayResultingMST(){
        
    }
}
