/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GraphFramework;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * 
 */
public class Vertex {
    public String label;
    public boolean isVisited = false;
    public LinkedList<Edge> adjList;
    public Vertex(String label){
        this.label=label;
        adjList = new LinkedList<>();
    }
    public String displayInfo(){
        return "Vertex label : "+label;
    }
}
