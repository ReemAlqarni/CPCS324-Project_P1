/*
 * 
 */
package GraphFramework;

/**
 *
 * 
 */
public class Edge {
    public int weight;
    public Vertex source;
    public Vertex target;
    public Vertex parent;
    public Edge(Vertex src, Vertex des, int weight){
        this.source=src;this.target=des;this.weight=weight;
    }
    public String displayInfo(){
        return "Edge weight : "+weight;
    }
}
